;(function (decoraki) { // jshint ignore:line
    'use strict';

    var template = decoraki.templates.header;
    var output = template();
    document.getElementById('header').innerHTML = output;

})(window.decoraki = window.decoraki || {});
